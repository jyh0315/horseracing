import React from 'react';

const PIP = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];

export default function DicePanel({ lastRoll }) {
  if (!lastRoll) return (
    <div className="dice-panel muted">하우스가 주사위를 준비하고 있습니다…</div>
  );
  const { d1, d2, sum, horseId, bonus, seq } = lastRoll;
  const special = d1 === 1 && d2 === 1 ? '스네이크 아이즈!' : d1 === 6 && d2 === 6 ? '박스카!' : null;
  return (
    <div className="dice-panel" key={seq}>
      <span className="die">{PIP[d1]}</span>
      <span className="die">{PIP[d2]}</span>
      <span className="roll-text">
        합 <b>{sum}</b> → <b>{horseId}번마</b> 전진
        {bonus > 0 && <em className="bonus-flash"> 연속! 보너스 +{bonus}칸</em>}
        {special && <em className="special-flash"> {special}</em>}
      </span>
    </div>
  );
}
